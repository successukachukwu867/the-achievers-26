# 🎓 The Achievers 26' — Finalist Card Generator

A full-stack web app that lets VTE finalists fill in their details, auto-generates their personalised card as a PNG using Puppeteer, and emails it to the admin via Gmail SMTP.

---

## 📁 Project Structure

```
achievers26/
├── server.js          ← Express backend (form processing, Puppeteer, Nodemailer)
├── package.json
├── .env.example       ← Copy this to .env and fill in your credentials
├── .gitignore
├── public/
│   └── index.html     ← The beautiful form UI
└── uploads/           ← Temp folder (auto-created, not committed)
```

---

## ⚙️ Setup

### 1. Clone & Install
```bash
git clone https://github.com/YOUR_USERNAME/achievers26-card.git
cd achievers26-card
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
```

Edit `.env`:
```
GMAIL_USER=yourgmail@gmail.com
GMAIL_PASS=your_16_char_app_password
ADMIN_EMAIL=admin@gmail.com
PORT=3000
```

> ⚠️ **Gmail App Password**: Go to Google Account → Security → 2-Step Verification → App Passwords. Generate one for "Mail". Use that 16-character code as `GMAIL_PASS`.

### 3. Run
```bash
npm start
```

Visit: **http://localhost:3000**

---

## 🔄 How It Works

1. Student fills in the form (name, photo, DOB, levels, quote, etc.)
2. On submit, the server:
   - Builds the full card HTML with all their data + photo embedded as base64
   - Uses **Puppeteer** to screenshot the card into a PNG
   - Uses **Nodemailer** to email the PNG to your admin Gmail
   - Returns the PNG as base64 to the browser
3. The student sees a **blurred preview** with watermarks saying *"Achievers 26'"* and the message:
   > *"Dear [Name], Your card is ready! You'll receive it very soon on your WhatsApp ✨"*

---

## 🚀 Deploying (Free Options)

### Railway.app (Recommended)
1. Push to GitHub
2. Go to [railway.app](https://railway.app), create new project from GitHub repo
3. Add environment variables in Railway dashboard
4. Deploy ✅

### Render.com
1. Push to GitHub
2. New Web Service → Connect repo
3. Build command: `npm install`
4. Start command: `node server.js`
5. Add env vars ✅

> **Note on Puppeteer on cloud:** Railway and Render support Chromium. If you get errors, add this to your start command:
> ```
> npx puppeteer browsers install chrome && node server.js
> ```

---

## 📧 Gmail SMTP Note

Make sure:
- 2-Step Verification is **ON** in your Google Account
- You use an **App Password** (not your regular Gmail password)
- Less secure app access is **NOT** needed with App Passwords

---

## ✏️ Customisation

- Edit student data in `public/index.html` (add/remove fields)
- Edit card design in the `buildCardHTML()` function in `server.js`
- Change admin email subject in `sendEmail()` in `server.js`
